shoplist = ['apple', 'mango', 'carrot', 'banana']
name = 'swaroop'

print('Item 0 is', shoplist[0])
print('Item 0 is', shoplist[0])
print('Item 0 is', shoplist[0])
print('Item 0 is', shoplist[0])
print('Item 0 is', shoplist[0])
print('Item 0 is', shoplist[0])
